﻿using System.Text;

public class Solver : ISolve
{
    private List<string> input = new();

    public void Accumulate(string s)
    {
        // add the string to the list
        input.Add(s);
    }

    public void Clear()
    {
        // clear the list
        input.Clear();
    }

    public double Solve()
    {
        double result = 0;

        // combine the input list into a single string
        string expression = string.Join(" ", input);

        // replace all instances of "- -" with "+" and "+ -" with "-"
        expression = expression.Replace("- -", "+");
        expression = expression.Replace("+ -", "-");

        // put everything back into the list
        input = expression.Split(' ').ToList();

        // get all of the numbers and put them together
        // (e.g. 1 0 0 will be 100 and 1 . 1 5 will be 1.15)
        input = ExtractNumbers(input);

        // evaluate multiplication, division, and modulus operations first
        while (input.Contains("*") || input.Contains("/") || input.Contains("%"))
        {
            for (int i = 1; i < input.Count - 1; i++)
            {
                // get the operator
                string op = input[i];
                if (op == "*" || op == "/" || op == "%")
                {
                    // get the first and second operands
                    double operand1 = double.Parse(input[i - 1]);
                    double operand2 = double.Parse(input[i + 1]);
                    double result2 = 0;
                    switch (op)
                    {
                        case "*":
                            result2 = operand1 * operand2;
                            break;
                        case "/":
                            result2 = operand1 / operand2;
                            break;
                        case "%":
                            result2 = operand1 % operand2;
                            break;
                    }

                    // replace the operands and operator with the result
                    input[i + 1] = result2.ToString();
                    input[i] = "";
                    input[i - 1] = "";
                }
            }

            // remove any empty elements from the list
            input.RemoveAll(op => string.IsNullOrEmpty(op));
        }

        // evaluate addition and subtraction operations second
        while (input.Contains("+") || input.Contains("-"))
        {
            for (int i = 1; i < input.Count - 1; i++)
            {
                // get the operator
                string op = input[i];
                if (op == "+" || op == "-")
                {
                    // get the first and second operands
                    double operand1 = double.Parse(input[i - 1]);
                    double operand2 = double.Parse(input[i + 1]);
                    double result2 = 0;
                    switch (op)
                    {
                        case "+":
                            result2 = operand1 + operand2;
                            break;
                        case "-":
                            result2 = operand1 - operand2;
                            break;
                    }

                    // replace the operands and operator with the result
                    input[i + 1] = result2.ToString();
                    input[i] = "";
                    input[i - 1] = "";
                }
            }

            // remove any empty elements from the list
            input.RemoveAll(op => string.IsNullOrEmpty(op));
        }

        // the result should be the only remaining element in the list
        result = double.Parse(input[0]);

        return result;
    }

    public List<string> ExtractNumbers(List<string> input)
    {
        List<string> numbers = new List<string>();
        StringBuilder sb = new StringBuilder();

        foreach (string s in input)
        {
            // append multicharacter numbers to a stringbuilder
            if (char.IsDigit(s[0]))
            {
                sb.Append(s);
            }
            else if (s[0] == '.')
            {
                sb.Append(s);
            }
            else
            {
                // add the number back to the list
                if (sb.Length > 0)
                {
                    numbers.Add(sb.ToString());
                    sb.Clear();
                }
                // add the operator
                numbers.Add(s);
            }
        }

        // add any last bit back to the list
        if (sb.Length > 0)
        {
            numbers.Add(sb.ToString());
        }

        return numbers;
    }
}