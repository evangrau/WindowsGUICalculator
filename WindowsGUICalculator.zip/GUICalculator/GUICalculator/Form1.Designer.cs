﻿namespace GUICalculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            zero_btn = new Button();
            seven_btn = new Button();
            eight_btn = new Button();
            four_btn = new Button();
            display = new TextBox();
            five_btn = new Button();
            one_btn = new Button();
            two_btn = new Button();
            three_btn = new Button();
            six_btn = new Button();
            nine_btn = new Button();
            period_btn = new Button();
            add_btn = new Button();
            sub_btn = new Button();
            mult_btn = new Button();
            equals_btn = new Button();
            div_btn = new Button();
            mod_btn = new Button();
            pos_neg_btn = new Button();
            clear_btn = new Button();
            SuspendLayout();
            // 
            // zero_btn
            // 
            zero_btn.Location = new Point(48, 576);
            zero_btn.Margin = new Padding(6);
            zero_btn.Name = "zero_btn";
            zero_btn.Size = new Size(264, 49);
            zero_btn.TabIndex = 0;
            zero_btn.Text = "0";
            zero_btn.UseVisualStyleBackColor = true;
            zero_btn.Click += zero_btn_Click;
            // 
            // seven_btn
            // 
            seven_btn.Location = new Point(48, 479);
            seven_btn.Margin = new Padding(6);
            seven_btn.Name = "seven_btn";
            seven_btn.Size = new Size(85, 49);
            seven_btn.TabIndex = 1;
            seven_btn.Text = "7";
            seven_btn.UseVisualStyleBackColor = true;
            seven_btn.Click += seven_btn_Click;
            // 
            // eight_btn
            // 
            eight_btn.Location = new Point(227, 479);
            eight_btn.Margin = new Padding(6);
            eight_btn.Name = "eight_btn";
            eight_btn.Size = new Size(85, 49);
            eight_btn.TabIndex = 2;
            eight_btn.Text = "8";
            eight_btn.UseVisualStyleBackColor = true;
            eight_btn.Click += eight_btn_Click;
            // 
            // four_btn
            // 
            four_btn.Location = new Point(48, 373);
            four_btn.Margin = new Padding(6);
            four_btn.Name = "four_btn";
            four_btn.Size = new Size(85, 49);
            four_btn.TabIndex = 3;
            four_btn.Text = "4";
            four_btn.UseVisualStyleBackColor = true;
            four_btn.Click += four_btn_Click;
            // 
            // display
            // 
            display.Location = new Point(22, 26);
            display.Margin = new Padding(6);
            display.Multiline = true;
            display.Name = "display";
            display.Size = new Size(853, 108);
            display.TabIndex = 4;
            display.Text = "\r\n-------------";
            display.TextAlign = HorizontalAlignment.Right;
            // 
            // five_btn
            // 
            five_btn.Location = new Point(227, 373);
            five_btn.Margin = new Padding(6);
            five_btn.Name = "five_btn";
            five_btn.Size = new Size(85, 49);
            five_btn.TabIndex = 5;
            five_btn.Text = "5";
            five_btn.UseVisualStyleBackColor = true;
            five_btn.Click += five_btn_Click;
            // 
            // one_btn
            // 
            one_btn.Location = new Point(48, 270);
            one_btn.Margin = new Padding(6);
            one_btn.Name = "one_btn";
            one_btn.Size = new Size(85, 49);
            one_btn.TabIndex = 6;
            one_btn.Text = "1";
            one_btn.UseVisualStyleBackColor = true;
            one_btn.Click += one_btn_Click;
            // 
            // two_btn
            // 
            two_btn.Location = new Point(227, 270);
            two_btn.Margin = new Padding(6);
            two_btn.Name = "two_btn";
            two_btn.Size = new Size(85, 49);
            two_btn.TabIndex = 7;
            two_btn.Text = "2";
            two_btn.UseVisualStyleBackColor = true;
            two_btn.Click += two_btn_Click;
            // 
            // three_btn
            // 
            three_btn.Location = new Point(407, 270);
            three_btn.Margin = new Padding(6);
            three_btn.Name = "three_btn";
            three_btn.Size = new Size(85, 49);
            three_btn.TabIndex = 8;
            three_btn.Text = "3";
            three_btn.UseVisualStyleBackColor = true;
            three_btn.Click += three_btn_Click;
            // 
            // six_btn
            // 
            six_btn.Location = new Point(407, 373);
            six_btn.Margin = new Padding(6);
            six_btn.Name = "six_btn";
            six_btn.Size = new Size(85, 49);
            six_btn.TabIndex = 9;
            six_btn.Text = "6";
            six_btn.UseVisualStyleBackColor = true;
            six_btn.Click += six_btn_Click;
            // 
            // nine_btn
            // 
            nine_btn.Location = new Point(407, 479);
            nine_btn.Margin = new Padding(6);
            nine_btn.Name = "nine_btn";
            nine_btn.Size = new Size(85, 49);
            nine_btn.TabIndex = 10;
            nine_btn.Text = "9";
            nine_btn.UseVisualStyleBackColor = true;
            nine_btn.Click += nine_btn_Click;
            // 
            // period_btn
            // 
            period_btn.Location = new Point(407, 576);
            period_btn.Margin = new Padding(6);
            period_btn.Name = "period_btn";
            period_btn.Size = new Size(85, 49);
            period_btn.TabIndex = 11;
            period_btn.Text = ".";
            period_btn.UseVisualStyleBackColor = true;
            period_btn.Click += period_btn_Click;
            // 
            // add_btn
            // 
            add_btn.Location = new Point(596, 270);
            add_btn.Margin = new Padding(6);
            add_btn.Name = "add_btn";
            add_btn.Size = new Size(85, 49);
            add_btn.TabIndex = 12;
            add_btn.Text = "+";
            add_btn.UseVisualStyleBackColor = true;
            add_btn.Click += add_btn_Click;
            // 
            // sub_btn
            // 
            sub_btn.Location = new Point(596, 373);
            sub_btn.Margin = new Padding(6);
            sub_btn.Name = "sub_btn";
            sub_btn.Size = new Size(85, 49);
            sub_btn.TabIndex = 13;
            sub_btn.Text = "-";
            sub_btn.UseVisualStyleBackColor = true;
            sub_btn.Click += sub_btn_Click;
            // 
            // mult_btn
            // 
            mult_btn.Location = new Point(596, 479);
            mult_btn.Margin = new Padding(6);
            mult_btn.Name = "mult_btn";
            mult_btn.Size = new Size(85, 49);
            mult_btn.TabIndex = 14;
            mult_btn.Text = "x";
            mult_btn.UseVisualStyleBackColor = true;
            mult_btn.Click += mult_btn_Click;
            // 
            // equals_btn
            // 
            equals_btn.Location = new Point(596, 576);
            equals_btn.Margin = new Padding(6);
            equals_btn.Name = "equals_btn";
            equals_btn.Size = new Size(85, 49);
            equals_btn.TabIndex = 15;
            equals_btn.Text = "=";
            equals_btn.UseVisualStyleBackColor = true;
            equals_btn.Click += equals_btn_Click;
            // 
            // div_btn
            // 
            div_btn.Location = new Point(596, 169);
            div_btn.Margin = new Padding(6);
            div_btn.Name = "div_btn";
            div_btn.Size = new Size(85, 49);
            div_btn.TabIndex = 16;
            div_btn.Text = "/";
            div_btn.UseVisualStyleBackColor = true;
            div_btn.Click += div_btn_Click;
            // 
            // mod_btn
            // 
            mod_btn.Location = new Point(407, 169);
            mod_btn.Margin = new Padding(6);
            mod_btn.Name = "mod_btn";
            mod_btn.Size = new Size(85, 49);
            mod_btn.TabIndex = 17;
            mod_btn.Text = "%";
            mod_btn.UseVisualStyleBackColor = true;
            mod_btn.Click += mod_btn_Click;
            // 
            // pos_neg_btn
            // 
            pos_neg_btn.Location = new Point(227, 169);
            pos_neg_btn.Margin = new Padding(6);
            pos_neg_btn.Name = "pos_neg_btn";
            pos_neg_btn.Size = new Size(109, 49);
            pos_neg_btn.TabIndex = 18;
            pos_neg_btn.Text = "+/-";
            pos_neg_btn.UseVisualStyleBackColor = true;
            pos_neg_btn.Click += pos_neg_btn_Click;
            // 
            // clear_btn
            // 
            clear_btn.Location = new Point(48, 169);
            clear_btn.Margin = new Padding(6);
            clear_btn.Name = "clear_btn";
            clear_btn.Size = new Size(109, 49);
            clear_btn.TabIndex = 19;
            clear_btn.Text = "AC";
            clear_btn.UseVisualStyleBackColor = true;
            clear_btn.Click += clear_btn_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(901, 651);
            Controls.Add(clear_btn);
            Controls.Add(pos_neg_btn);
            Controls.Add(mod_btn);
            Controls.Add(div_btn);
            Controls.Add(equals_btn);
            Controls.Add(mult_btn);
            Controls.Add(sub_btn);
            Controls.Add(add_btn);
            Controls.Add(period_btn);
            Controls.Add(nine_btn);
            Controls.Add(six_btn);
            Controls.Add(three_btn);
            Controls.Add(two_btn);
            Controls.Add(one_btn);
            Controls.Add(five_btn);
            Controls.Add(display);
            Controls.Add(four_btn);
            Controls.Add(eight_btn);
            Controls.Add(seven_btn);
            Controls.Add(zero_btn);
            Margin = new Padding(6);
            Name = "Form1";
            Text = "GUI Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button zero_btn;
        private Button seven_btn;
        private Button eight_btn;
        private Button four_btn;
        private TextBox display;
        private Button five_btn;
        private Button one_btn;
        private Button two_btn;
        private Button three_btn;
        private Button six_btn;
        private Button nine_btn;
        private Button period_btn;
        private Button add_btn;
        private Button sub_btn;
        private Button mult_btn;
        private Button equals_btn;
        private Button div_btn;
        private Button mod_btn;
        private Button pos_neg_btn;
        private Button clear_btn;
    }
}