namespace GUICalculator
{
    public partial class Form1 : Form
    {
        Solver solver;
        private string upperText = string.Empty;
        public Form1()
        {
            InitializeComponent();
            display.ReadOnly = true;
            solver = new Solver();
        }

        private void clear_btn_Click(object sender, EventArgs e)
        {
            upperText = string.Empty;
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Clear();
        }

        private void equals_btn_Click(object sender, EventArgs e)
        {
            double result = solver.Solve();
            display.Text = upperText + "\r\n-------------\r\n" + result.ToString();
        }

        private void one_btn_Click(object sender, EventArgs e)
        {
            upperText += "1";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("1");
        }

        private void four_btn_Click(object sender, EventArgs e)
        {
            upperText += "4";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("4");
        }

        private void seven_btn_Click(object sender, EventArgs e)
        {
            upperText += "7";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("7");
        }

        private void zero_btn_Click(object sender, EventArgs e)
        {
            upperText += "0";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("0");
        }

        private void two_btn_Click(object sender, EventArgs e)
        {
            upperText += "2";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("2");
        }

        private void five_btn_Click(object sender, EventArgs e)
        {
            upperText += "5";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("5");
        }

        private void eight_btn_Click(object sender, EventArgs e)
        {
            upperText += "8";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("8");
        }

        private void three_btn_Click(object sender, EventArgs e)
        {
            upperText += "3";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("3");
        }

        private void six_btn_Click(object sender, EventArgs e)
        {
            upperText += "6";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("6");
        }

        private void nine_btn_Click(object sender, EventArgs e)
        {
            upperText += "9";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("9");
        }

        private void period_btn_Click(object sender, EventArgs e)
        {
            upperText += ".";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate(".");
        }

        private void div_btn_Click(object sender, EventArgs e)
        {
            upperText += "/";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("/");
        }

        private void add_btn_Click(object sender, EventArgs e)
        {
            upperText += "+";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("+");
        }

        private void sub_btn_Click(object sender, EventArgs e)
        {
            upperText += "-";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("-");
        }

        private void mult_btn_Click(object sender, EventArgs e)
        {
            upperText += "*";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("*");
        }

        private void mod_btn_Click(object sender, EventArgs e)
        {
            upperText += "%";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("%");
        }

        private void pos_neg_btn_Click(object sender, EventArgs e)
        {
            upperText += "-";
            display.Text = upperText + "\r\n-------------\r\n";
            solver.Accumulate("-");
        }
    }
}